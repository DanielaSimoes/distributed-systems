To run machines.py - upload the files to the machines and get the result log:
 
$ python3 machines.py upload get_log

