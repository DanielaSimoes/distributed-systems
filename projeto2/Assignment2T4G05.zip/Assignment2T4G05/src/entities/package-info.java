/**
* This package contains the entities that are part of the problem: HorseJockey, Broker and the Spectator.
*/

package entities;