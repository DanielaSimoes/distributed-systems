/**
* This package contains the shared memory: paddock, stable, racing track, stable, betting centre and control centre.
*/

package shared;