/**
* This package contains all the information of the races' state, including all entities' state; this package is responsible to write in a file
* a log since the beginning of the races until the last one - until every entity finishes.
*/

package GeneralRepository;