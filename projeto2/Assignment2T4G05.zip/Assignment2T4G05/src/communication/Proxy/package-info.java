/**
* This package contains the the client and server proxy.
*/

package communication.Proxy;