/**
* This package contains the methods to construct the messages, the type messages available and a message wrapper.
*/

package communication.message;