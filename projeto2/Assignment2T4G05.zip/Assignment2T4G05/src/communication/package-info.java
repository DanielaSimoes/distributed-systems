/**
* This package contains the client and server channels and other packages.
*/

package communication;